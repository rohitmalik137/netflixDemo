function showContent(res){
	console.log(res+""+res);
	var ans = res+""+res;
	var ans = document.getElementById(ans);
	plus = document.getElementById(res);
	if (ans.style.display == "none") {
		ans.style.display = "block";
		plus.innerHTML = "x";
		document.getElementById('ques').style.height = "1200px";
		document.getElementById('ques').style.clipPath = "polygon(0 10%, 100% 0, 100% 85%, 0% 100%)";
	}else{
		ans.style.display = "none";
		plus.innerHTML = "+";
		document.getElementById('ques').style.height = "900px";
		document.getElementById('ques').style.clipPath = "polygon(0 13.5%, 100% 0, 100% 80%, 0% 100%)";
	}
}